CIS 15 Final Project 
Caitlin Baker

My final project is a five function web calculator. It supports five functions
+, -, *, /, and exponent. The user enters an expression containing only numbers and the
supported operations (the app des not support parentheses or variables) separated by a single space and using
the provided web form. The app returns the result of the calculation at a separate /results url.

You can find it hosted on: 

  https://caitlin-final.appspot.com 
  
Requirements met (indicate what file/line if yes): 

  - Has a class: Yes, main.py line 15 
  - Uses a list or dictionary: Yes, main.py line 20 and line 35 
  - Uses a for or while loop: Yes, main.py lines 37 - 60 
  - Takes input using a form: Yes, calc_form2.html line 22 - 32
  - All python files with a docstring: Yes, main.py
  - All classes with a docstring: Yes
  - All functions with a docstring: Yes 

