"""
CIS 15 Final Project
Five Function Web Calculator
Caitlin Baker
"""

from __future__ import print_function 

import traceback 
import operator
from flask import Flask, request, render_template

app = Flask(__name__)

class calculator(object):
    """This class creates a calculator object that parses the user input and performs the desired calculations"""
    
    def __init__(self):
        """The __init__ function initializes the operator string characters to map them to math operations using a dictionary"""
        self.ops = {
            "+": operator.add,
            "-": operator.sub,
            "*": operator.mul,
            "/": operator.truediv,
            "**": operator.pow,
        }
        return
        
    def get_result(self, expression):
        """This function parses the user input and performs the math operations following the order of operations.
        The function returns the result of the calculations as a string"""
        
        expression_list = expression.split(' ')
        
        while len(expression_list) > 1:
            while '**' in expression_list:
                for x in range(len(expression_list)):
                    if expression_list[x] == '**':
                        op_function = self.ops[expression_list[x]]
                        expression_list[x-1:x+2] = [op_function(float(expression_list[x-1]),float(expression_list[x+1]))]
                        break
            while '*' in expression_list or '/' in expression_list:
                for x in range(len(expression_list)):
                    if expression_list[x] == '*' or expression_list[x] == '/':
                        try:
                            op_function = self.ops[expression_list[x]]
                            expression_list[x-1:x+2] = [op_function(float(expression_list[x-1]),float(expression_list[x+1]))]
                            break
                        except ZeroDivisionError:
                            return 'Undefined'
                        except ValueError:
                            return "Enter numbers or supported operators only"
            for x in range(len(expression_list)):
                if expression_list[x] == '+' or expression_list[x] == '-':
                    op_function = self.ops[expression_list[x]]
                    expression_list[x-1:x+2] = [op_function(float(expression_list[x-1]),float(expression_list[x+1]))]
                    break
                
        result = str(expression_list[0])
        return result
        
@app.route('/', methods=['GET'])
def do_form():
    """Funtion to render the html template to display the index page. It routes to '/' and gets user 
    input of a math expression as a string. It retunns a rendered html template"""
    return render_template('calc_form2.html')
    
@ app.route('/results', methods=['POST'])
def do_result():
    """Function to render the html template for the results page. It uses the calculator class to do 
    the desired operations on the user input. It returns a rendered html template"""
    
    calc = calculator()
    expression = request.form['expression']
    result = str(calc.get_result(expression))
    
    return render_template('results.html', result=result)


@app.errorhandler(500)
def server_error(e):
    """Function handles errors"""
    print (traceback.format_exc())
    return traceback.format_exc(), 500, {'Content-Type': 'text/plain; charset=utf-8'}

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=8080)