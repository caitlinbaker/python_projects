# appengine_config.py
from google.appengine.ext import vendor
import tempfile
tempfile.SpooledTemporaryFile = tempfile.TemporaryFile

# Add any libraries install in the "lib" folder.
vendor.add('lib')
